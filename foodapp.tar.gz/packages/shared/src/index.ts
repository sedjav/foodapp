export type Id = string;

export type MoneyIrr = number;

export type EventState = "DRAFT" | "OPEN" | "LOCKED" | "COMPLETED";
