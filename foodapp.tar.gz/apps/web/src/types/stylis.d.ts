declare module "stylis" {
  export const prefixer: any;
}

declare module "stylis-plugin-rtl" {
  const rtlPlugin: any;
  export default rtlPlugin;
}
